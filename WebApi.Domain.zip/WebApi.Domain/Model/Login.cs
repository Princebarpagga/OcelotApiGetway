﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.Domain.Model
{
    public class Login
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string userRole { get; set; }
    }
   

    
}
